<?php
session_start();

// DB connection (same as other agri_mgmt files)
$host = 'localhost';
$dbname = 'agri_mgmt';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Category-wise totals for current user
$stmt = $pdo->prepare("
    SELECT category,
           COUNT(*) AS item_count,
           SUM(quantity) AS total_qty,
           SUM(price * quantity) AS stock_value
    FROM agro_items
    WHERE added_by = ?
    GROUP BY category
    ORDER BY stock_value DESC
");
$stmt->execute([$_SESSION['user_id'] ?? 0]);
$categoryRows = $stmt->fetchAll();

// Overall totals
$stmt2 = $pdo->prepare("
    SELECT 
        COUNT(*) AS total_items,
        SUM(quantity) AS total_qty,
        SUM(price * quantity) AS total_value
    FROM agro_items
    WHERE added_by = ?
");
$stmt2->execute([$_SESSION['user_id'] ?? 0]);
$totals = $stmt2->fetch();

// Recent items
$stmt3 = $pdo->prepare("
    SELECT name, category, quantity, price, added_at
    FROM agro_items
    WHERE added_by = ?
    ORDER BY added_at DESC
    LIMIT 10
");
$stmt3->execute([$_SESSION['user_id'] ?? 0]);
$recentItems = $stmt3->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agricultural Reports</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #88f1f1ff 0%, #ca67b1ff 100%); min-height: 100vh; }
        .glass { background: rgba(118, 252, 141, 0.66); backdrop-filter: blur(18px);
                 border-radius: 18px; border:1px solid rgba(8, 252, 101, 0.93); }
        .stat-card { color:black; }
        .table thead th { background: rgba(104, 245, 139, 1); color:red; }
        .table tbody td { color:red; }
    </style>
</head>
<body class="py-4">
<nav class="navbar navbar-expand-lg navbar-dark bg-success shadow">
    <div class="container">
        <a class="navbar-brand fs-3">🌾 Agri Management</a>
        <div class="navbar-nav ms-auto">
            <a href="dashboard.php" class="nav-link">Dashboard</a>
            <a href="view_items.php" class="nav-link">View Items</a>
            <a href="dashboard.php?logout=1" class="nav-link">Logout</a>
        </div>
    </div>
</nav>

<div class="container py-4">
    <!-- Overall stats -->
    <div class="row g-4 mb-4">
        <div class="col-md-4">
            <div class="glass p-4 stat-card text-center">
                <h2><?php echo $totals['total_items'] ?? 0; ?></h2>
                <p class="mb-0">Total Items</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass p-4 stat-card text-center">
                <h2><?php echo $totals['total_qty'] ?? 0; ?></h2>
                <p class="mb-0">Total Quantity (all items)</p>
            </div>
        </div>
        <div class="col-md-4">
            <div class="glass p-4 stat-card text-center">
                <h2>₹<?php echo number_format($totals['total_value'] ?? 0, 2); ?></h2>
                <p class="mb-0">Total Stock Value</p>
            </div>
        </div>
    </div>

    <div class="row g-4">
        <!-- Category summary -->
        <div class="col-lg-6">
            <div class="glass p-4 h-100">
                <h4 class="text-black mb-3">📊 Category-wise Summary</h4>
                <?php if ($categoryRows): ?>
                <div class="table-responsive">
                    <table class="table table-borderless align-middle">
                        <thead>
                        <tr>
                            <th class="text-black">Category</th>
                            <th class="text-black">Items</th>
                            <th class="text-black">Total Qty</th>
                            <th class="text-black">Stock Value (₹)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($categoryRows as $row): ?>
                            <tr>
                                <td class="text-black"><?php echo htmlspecialchars($row['category']); ?></td>
                                <td class="text-black"><?php echo $row['item_count']; ?></td>
                                <td class="text-black"><?php echo $row['total_qty']; ?></td>
                                <td class="text-black">₹<?php echo number_format($row['stock_value'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <p class="text-black-50 mb-0">No items found. Add some machinery or fertilizers first.</p>
                <?php endif; ?>
            </div>
        </div>

        <!-- Recent items -->
        <div class="col-lg-6">
            <div class="glass p-4 h-100">
                <h4 class="text-black mb-3">🕒 Recent Items</h4>
                <?php if ($recentItems): ?>
                <div class="table-responsive">
                    <table class="table table-borderless align-middle">
                        <thead>
                        <tr>
                            <th class="text-black">Name</th>
                            <th class="text-black">Category</th>
                            <th class="text-black">Qty</th>
                            <th class="text-black">Price (₹)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recentItems as $it): ?>
                            <tr>
                                <td class="text-black"><?php echo htmlspecialchars($it['name']); ?></td>
                                <td class="text-black"><?php echo htmlspecialchars($it['category']); ?></td>
                                <td class="text-black"><?php echo $it['quantity']; ?></td>
                                <td class="text-black">₹<?php echo number_format($it['price'], 2); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <?php else: ?>
                    <p class="text-black-50 mb-0">No items added yet.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
</body>
</html>