<?php 
include 'config.php'; 
$error = '';
if ($_POST) {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE username = ?");
    $stmt->execute([$_POST['username']]);
    $user = $stmt->fetch();
    
    if ($user && password_verify($_POST['password'], $user['password'])) {
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];
        $_SESSION['role'] = $user['role'];
        header('Location: dashboard.php');
        exit;
    } else {
        $error = "Invalid credentials!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agri Management - Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #88f1f1ff 0%, #ca67b1ff 100%); min-height: 100vh; }
        .login-card { background: rgba(99, 240, 153, 0.95); backdrop-filter: blur(200px); }
    </style>
</head>
<body class="d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card login-card shadow-lg p-4">
                    <div class="text-center mb-4">
                        <h1 class="text-success">🌾 Agri Management</h1>
                        <p class="lead">Agricultural Resource System</p>
                    </div>
                    <?php if ($error): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
                    <form method="POST">
                        <div class="mb-4">
                            <input type="text" name="username" class="form-control form-control-lg" placeholder="Username" required>
                        </div>
                        <div class="mb-4">
                            <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" required>
                        </div>
                        <button type="submit" class="btn btn-success w-100 btn-lg">Login</button>
                    </form>
                    <p class="text-center mt-3">New user? <a href="register.php" class="text-primary fw-bold">Register here</a></p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

