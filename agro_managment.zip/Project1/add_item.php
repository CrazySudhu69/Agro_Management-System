<?php
include 'config.php';
if ($_POST) {
    $stmt = $pdo->prepare("INSERT INTO agro_items (category, name, price, quantity, description, supplier, added_by) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$_POST['category'], $_POST['name'], $_POST['price'], $_POST['quantity'], $_POST['description'], $_POST['supplier'], $_SESSION['user_id']]);
    $success = "Item added successfully!";
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Agri Item</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> body { background: linear-gradient(135deg, #91dff3ff 0%, #e076f5ff 100%); }
        .login-card { background: rgba(159, 233, 238, 0.95); backdrop-filter: blur(200px); }
     </style>
</head>
<body class="py-5">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-7">
                <div class="card login-card p-4 rounded-4">
                    <h2 class="text-success mb-4 text-center">➕ Add Agricultural Item</h2>
                    <?php if (isset($success)): ?><div class="alert alert-success"><?php echo $success; ?></div><?php endif; ?>
                    <form method="POST">
                        <div class="row g-4">
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-black">Category</label>
                                <select name="category" class="form-select form-select-lg" required>
                                    <option value="Tractor">🚜 Tractor</option>
                                    <option value="Harvester">🌾 Harvester</option>
                                    <option value="Fertilizer">🧪 Fertilizer</option>
                                    <option value="Seeds">🌱 Seeds</option>
                                    <option value="Pesticides">🛡️ Pesticides</option>
                                    <option value="Irrigation">💧 Irrigation</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-black">Item Name</label>
                                <input type="text" name="name" class="form-control form-control-lg" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-black">Price (₹)</label>
                                <input type="number" step="0.01" name="price" class="form-control form-control-lg" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-black">Quantity</label>
                                <input type="number" name="quantity" class="form-control form-control-lg" required>
                            </div>
                            <div class="col-12">
                                <label class="form-label fw-bold text-black">Description</label>
                                <textarea name="description" class="form-control form-control-lg" rows="3"></textarea>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-black">Supplier</label>
                                <input type="text" name="supplier" class="form-control form-control-lg">
                            </div>
                        </div>
                        <div class="mt-4">
                            <a href="dashboard.php" class="btn btn-success btn-lg px-5">← Dashboard</a>
                            <button type="submit" class="btn btn-success btn-lg px-5">Save Item</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</body>
</html>