<?php
include 'config.php';
if ($_POST) {
    $stmt = $pdo->prepare("UPDATE agro_items SET category=?, name=?, price=?, quantity=?, description=?, supplier=? WHERE id=? AND added_by=?");
    $stmt->execute([$_POST['category'], $_POST['name'], $_POST['price'], $_POST['quantity'], $_POST['description'], $_POST['supplier'], $_POST['id'], $_SESSION['user_id']]);
    header('Location: view_items.php?success=1');
    exit;
}
?>