<?php
include 'config.php';

// Handle Delete
if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM agro_items WHERE id = ? AND added_by = ?");
    $stmt->execute([$_GET['delete'], $_SESSION['user_id']]);
    header('Location: view_items.php');
    exit;
}

// Handle Edit (pre-populate form)
$edit_item = null;
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare("SELECT * FROM agro_items WHERE id = ? AND added_by = ?");
    $stmt->execute([$_GET['edit'], $_SESSION['user_id']]);
    $edit_item = $stmt->fetch();
}

// Search & Filter
$search = $_GET['search'] ?? '';
$category_filter = $_GET['category'] ?? '';
$where = "added_by = ?";
$params = [$_SESSION['user_id']];

if ($search) {
    $where .= " AND (name LIKE ? OR supplier LIKE ? OR description LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($category_filter) {
    $where .= " AND category = ?";
    $params[] = $category_filter;
}

$stmt = $pdo->prepare("SELECT * FROM agro_items WHERE $where ORDER BY added_at DESC");
$stmt->execute($params);
$items = $stmt->fetchAll();

// Get categories for filter
$categories = $pdo->query("SELECT DISTINCT category FROM agro_items ORDER BY category")->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>View Agri Items</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #8fe3f1ff 0%, #e6a0f8ff 100%); min-height: 100vh; }
        .glass { background: rgba(255,255,255,0.1); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.2); }
        .item-card { transition: transform 0.2s; }
        .item-card:hover { transform: translateY(-5px); }
        .tractor { border-left: 5px solid #28a745; }
        .harvester { border-left: 5px solid #ffc107; }
        .fertilizer { border-left: 5px solid #17a2b8; }
        .seeds { border-left: 5px solid #6f42c1; }
        .pesticides { border-left: 5px solid #dc3545; }
        .irrigation { border-left: 5px solid #fd7e14; }
    </style>
</head>
<body class="py-4">
    <nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-lg mb-4">
        <div class="container">
            <a class="navbar-brand fs-3">🌾 Agri Management</a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">👋 <?php echo $_SESSION['username']; ?></span>
                <a href="dashboard.php" class="nav-link">Dashboard</a>
                <a href="dashboard.php?logout=1" class="nav-link">Logout</a>
            </div>
        </div>
    </nav>

    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h2 class="text-black">📋 Agricultural Items (<?php echo count($items); ?>)</h2>
            <a href="add_item.php" class="btn btn-success btn-lg">➕ Add New Item</a>
        </div>

        <!-- Search & Filter -->
        <div class="glass p-4 rounded-4 mb-4">
            <form method="GET" class="row g-3">
                <div class="col-md-5">
                    <input type="text" name="search" class="form-control form-control-lg" placeholder="Search name, supplier, description..." value="<?php echo htmlspecialchars($search); ?>">
                </div>
                <div class="col-md-4">
                    <select name="category" class="form-select form-select-lg">
                        <option value="">All Categories</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?php echo $cat['category']; ?>" <?php echo ($category_filter == $cat['category']) ? 'selected' : ''; ?>>
                                <?php echo $cat['category']; ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn btn-success w-100 h-100 fs-5">🔍 Filter</button>
                </div>
            </form>
        </div>

        <!-- Edit Form (Modal-like) -->
        <?php if ($edit_item): ?>
        <div class="glass p-5 rounded-4 mb-4">
            <h4 class="text-black mb-4">✏️ Edit Item: <?php echo htmlspecialchars($edit_item['name']); ?></h4>
            <form method="POST" action="edit_item.php">
                <input type="hidden" name="id" value="<?php echo $edit_item['id']; ?>">
                <div class="row g-4">
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-black">Category</label>
                        <select name="category" class="form-select form-select-lg" required>
                            <option value="Tractor" <?php echo $edit_item['category']=='Tractor'?'selected':'';?>>🚜 Tractor</option>
                            <option value="Harvester" <?php echo $edit_item['category']=='Harvester'?'selected':'';?>>🌾 Harvester</option>
                            <option value="Fertilizer" <?php echo $edit_item['category']=='Fertilizer'?'selected':'';?>>🧪 Fertilizer</option>
                            <option value="Seeds" <?php echo $edit_item['category']=='Seeds'?'selected':'';?>>🌱 Seeds</option>
                            <option value="Pesticides" <?php echo $edit_item['category']=='Pesticides'?'selected':'';?>>🛡️ Pesticides</option>
                            <option value="Irrigation" <?php echo $edit_item['category']=='Irrigation'?'selected':'';?>>💧 Irrigation</option>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-black">Name</label>
                        <input type="text" name="name" class="form-control form-control-lg" value="<?php echo htmlspecialchars($edit_item['name']); ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-black">Price (₹)</label>
                        <input type="number" step="0.01" name="price" class="form-control form-control-lg" value="<?php echo $edit_item['price']; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-black">Quantity</label>
                        <input type="number" name="quantity" class="form-control form-control-lg" value="<?php echo $edit_item['quantity']; ?>" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold text-black">Supplier</label>
                        <input type="text" name="supplier" class="form-control form-control-lg" value="<?php echo htmlspecialchars($edit_item['supplier']); ?>">
                    </div>
                    <div class="col-12">
                        <label class="form-label fw-bold text-black">Description</label>
                        <textarea name="description" class="form-control form-control-lg" rows="3"><?php echo htmlspecialchars($edit_item['description']); ?></textarea>
                    </div>
                </div>
                <div class="mt-4">
                    <a href="view_items.php" class="btn btn-outline-secondary btn-lg me-2">Cancel</a>
                    <button type="submit" class="btn btn-primary btn-lg px-5">💾 Update Item</button>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- Items Grid -->
        <?php if ($items): ?>
        <div class="row g-4">
            <?php foreach ($items as $item): ?>
            <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="item-card glass p-4 rounded-4 h-100 <?php echo strtolower($item['category']); ?>">
                    <div class="d-flex justify-content-between align-items-start mb-3">
                        <h5 class="text-black fw-bold mb-2"><?php echo htmlspecialchars($item['name']); ?></h5>
                        <span class="badge fs-6 px-3 py-2 bg-light text-dark"><?php echo $item['quantity']; ?> units</span>
                    </div>
                    
                    <div class="mb-3">
                        <span class="badge bg-success fs-6 px-3 py-2">₹<?php echo number_format($item['price'], 2); ?></span>
                        <?php if ($item['supplier']): ?>
                            <small class="text-black-50 d-block mt-1"><?php echo htmlspecialchars($item['supplier']); ?></small>
                        <?php endif; ?>
                    </div>
                    
                    <p class="text-black-75 mb-3 small"><?php echo substr(htmlspecialchars($item['description'] ?: 'No description'), 0, 100); ?>...</p>
                    
                    <div class="d-flex gap-2">
                        <a href="?edit=<?php echo $item['id']; ?>" class="btn btn-outline-secondary">✏️ Edit</a>
                        <a href="?delete=<?php echo $item['id']; ?>" class="btn btn-outline-danger btn-sm" onclick="return confirm('Delete <?php echo htmlspecialchars($item['name']); ?>?')">🗑️ Delete</a>
                    </div>
                    
                    <small class="text-black-50 d-block mt-2">Added: <?php echo date('M j, Y', strtotime($item['added_at'])); ?></small>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <?php else: ?>
        <div class="glass text-center p-5 rounded-4">
            <h4 class="text-black mb-3">📭 No items found</h4>
            <p class="text-black-50 mb-4">Try adjusting your search or add your first agricultural item.</p>
            <a href="add_item.php" class="btn btn-success btn-lg">➕ Add First Item</a>
        </div>
        <?php endif; ?>
    </div>
</body>
</html>