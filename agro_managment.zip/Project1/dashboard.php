<?php 
include 'config.php'; 

// More dynamic stats
$user_items = $pdo->prepare("SELECT COUNT(*) FROM agro_items WHERE added_by = ?");
$user_items->execute([$_SESSION['user_id']]);
$total_items = $user_items->fetchColumn();

$total_value = $pdo->prepare("SELECT COALESCE(SUM(price * quantity), 0) as value FROM agro_items WHERE added_by = ?");
$total_value->execute([$_SESSION['user_id']]);
$total_value = $total_value->fetchColumn();

$low_stock = $pdo->prepare("SELECT COUNT(*) FROM agro_items WHERE added_by = ? AND quantity < 10");
$low_stock->execute([$_SESSION['user_id']]);
$low_stock = $low_stock->fetchColumn();

$categories = $pdo->prepare("SELECT category, COUNT(*) as count, SUM(price*quantity) as value FROM agro_items WHERE added_by = ? GROUP BY category ORDER BY value DESC");
$categories->execute([$_SESSION['user_id']]);
$categories = $categories->fetchAll();

// Recent activity
$recent = $pdo->prepare("SELECT name, category, quantity, price, added_at FROM agro_items WHERE added_by = ? ORDER BY added_at DESC LIMIT 5");
$recent->execute([$_SESSION['user_id']]);
$recent = $recent->fetchAll();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agri Dashboard</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height:100vh; font-family: 'Segoe UI', sans-serif; }
        .glass { background: rgba(255,255,255,0.12); backdrop-filter: blur(20px); border: 1px solid rgba(255,255,255,0.3); border-radius: 20px; }
        .metric-card { transition: all 0.3s ease; cursor: pointer; }
        .metric-card:hover { transform: translateY(-8px); box-shadow: 0 20px 40px rgba(0,0,0,0.2); }
        .low-stock { animation: pulse 2s infinite; }
        @keyframes pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.7; } }
    </style>
</head>
<body>
    <!-- Enhanced Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-success shadow-lg">
        <div class="container">
            <a class="navbar-brand fs-2 fw-bold">
                <i class="fas fa-seedling me-2"></i>Agri Management
            </a>
            <div class="navbar-nav ms-auto align-items-center">
                <span class="navbar-text me-3">
                    <i class="fas fa-user-circle me-1"></i><?php echo htmlspecialchars($_SESSION['username']); ?>
                </span>
                <a href="?logout=1" class="btn btn-outline-light btn-sm">
                    <i class="fas fa-sign-out-alt me-1"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <!-- Welcome Header with dynamic greeting -->
        <div class="text-white text-center mb-5">
            <h1 class="display-4 fw-bold mb-3">
                <i class="fas fa-tractor me-3"></i>Welcome Back!
            </h1>
            <p class="lead mb-0 opacity-90">Manage your agricultural inventory effectively</p>
        </div>

        <!-- Dynamic Metrics Row -->
        <div class="row g-4 mb-5">
            <div class="col-xl-3 col-md-6">
                <div class="glass p-4 metric-card text-center text-white h-100" onclick="location.href='view_items.php'">
                    <i class="fas fa-boxes fa-3x mb-3 opacity-75"></i>
                    <h2 class="display-5 fw-bold mb-1"><?php echo $total_items; ?></h2>
                    <p class="mb-0 lead">Total Items</p>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="glass p-4 metric-card text-center text-white h-100" onclick="location.href='reports.php'">
                    <i class="fas fa-coins fa-3x mb-3 opacity-75"></i>
                    <h4 class="display-5 fw-bold mb-1">₹<?php echo number_format($total_value, 2); ?></h4>
                    <p class="mb-0 lead">Stock Value</p>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="glass p-4 metric-card text-center <?php echo $low_stock > 0 ? 'text-warning low-stock' : 'text-success'; ?> h-100">
                    <i class="fas fa-exclamation-triangle fa-3x mb-3 <?php echo $low_stock > 0 ? 'text-warning' : 'text-success'; ?>"></i>
                    <h2 class="display-5 fw-bold mb-1"><?php echo $low_stock; ?></h2>
                    <p class="mb-0 lead"><?php echo $low_stock > 0 ? 'Low Stock Items' : 'All Stock OK'; ?></p>
                </div>
            </div>
            <div class="col-xl-3 col-md-6">
                <div class="glass p-4 metric-card text-center text-white h-100">
                    <i class="fas fa-calendar-day fa-3x mb-3 opacity-75"></i>
                    <h2 class="display-5 fw-bold mb-1"><?php echo date('M j'); ?></h2>
                    <p class="mb-0 lead">Today</p>
                </div>
            </div>
        </div>

        <!-- Category Breakdown - Animated Chart-like -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="glass p-5">
                    <h3 class="text-white mb-4">
                        <i class="fas fa-chart-pie me-2"></i>Inventory by Category
                    </h3>
                    <div class="row g-4">
                        <?php if ($categories): ?>
                            <?php foreach ($categories as $cat): ?>
                            <div class="col-md-4 col-lg-3">
                                <div class="text-center p-4 rounded-3" style="background: rgba(255,255,255,0.15);">
                                    <div class="h3 fw-bold text-white mb-2"><?php echo $cat['count']; ?></div>
                                    <div class="h6 text-white-50 mb-2"><?php echo htmlspecialchars($cat['category']); ?></div>
                                    <div class="text-warning fw-bold">₹<?php echo number_format($cat['value'], 0); ?></div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <div class="col-12 text-center py-5">
                                <i class="fas fa-inbox fa-4x text-white-50 mb-3"></i>
                                <h4 class="text-white-50">No items yet</h4>
                                <a href="add_item.php" class="btn btn-success btn-lg mt-3">Add First Item</a>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="row mb-5">
            <div class="col-12">
                <div class="glass p-5">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h3 class="text-white mb-0">
                            <i class="fas fa-history me-2"></i>Recent Activity
                        </h3>
                        <a href="view_items.php" class="btn btn-outline-light btn-sm">View All <i class="fas fa-arrow-right ms-1"></i></a>
                    </div>
                    
                    <?php if ($recent): ?>
                    <div class="table-responsive">
                        <table class="table table-dark table-hover">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Category</th>
                                    <th>Qty</th>
                                    <th>Value</th>
                                    <th>Added</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($recent as $item): ?>
                                <tr>
                                    <td><strong><?php echo htmlspecialchars($item['name']); ?></strong></td>
                                    <td>
                                        <span class="badge bg-success"><?php echo htmlspecialchars($item['category']); ?></span>
                                    </td>
                                    <td><span class="badge bg-info"><?php echo $item['quantity']; ?></span></td>
                                    <td>₹<?php echo number_format($item['price'] * $item['quantity'], 0); ?></td>
                                    <td class="text-white"><?php echo date('M j H:i', strtotime($item['added_at'])); ?></td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php else: ?>
                    <div class="text-center py-5">
                        <i class="fas fa-clock fa-4x text-white-50 mb-4"></i>
                        <h4 class="text-white-50">No recent activity</h4>
                        <p class="text-muted mb-4">Add your first agricultural item to get started</p>
                        <a href="add_item.php" class="btn btn-success btn-lg px-5">➕ Add Item Now</a>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Action Buttons - Larger & More Prominent -->
        <div class="row g-4">
            <div class="col-xl-3 col-md-6">
                <a href="add_item.php" class="btn btn-success btn-lg w-100 h-100 fs-3 rounded-4 p-5 d-flex align-items-center justify-content-center text-decoration-none">
                    <i class="fas fa-plus-circle fa-2x me-3"></i>Add Item
                </a>
            </div>
            <div class="col-xl-3 col-md-6">
                <a href="view_items.php" class="btn btn-info btn-lg w-100 h-100 fs-3 rounded-4 p-5 d-flex align-items-center justify-content-center text-decoration-none">
                    <i class="fas fa-list fa-2x me-3"></i>View Items
                </a>
            </div>
            <div class="col-xl-3 col-md-6">
                <a href="reports.php" class="btn btn-warning btn-lg w-100 h-100 fs-3 rounded-4 p-5 d-flex align-items-center justify-content-center text-decoration-none">
                    <i class="fas fa-chart-bar fa-2x me-3"></i>Reports
                </a>
            </div>
            <div class="col-xl-3 col-md-6">
                <a href="#" onclick="window.print()" class="btn btn-secondary btn-lg w-100 h-100 fs-3 rounded-4 p-5 d-flex align-items-center justify-content-center text-decoration-none">
                    <i class="fas fa-print fa-2x me-3"></i>Print Summary
                </a>
            </div>
        </div>
    </div>

    <?php if (isset($_GET['logout'])) { session_destroy(); header('Location: login.php'); exit; } ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>