<?php 
include 'config.php'; 
if ($_POST) {
    try {
        $stmt = $pdo->prepare("INSERT INTO users (username, email, contact, password) VALUES (?, ?, ?, ?)");
        $stmt->execute([
            $_POST['username'], 
            $_POST['email'], 
            $_POST['contact'], 
            password_hash($_POST['password'], PASSWORD_DEFAULT)
        ]);
        header('Location: login.php?success=1');
        exit;
    } catch(PDOException $e) {
        $error = "Username or email already exists!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Agri Management - Register</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style> 
        body { background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%); min-height: 100vh; } 
        .login-card { background: rgba(255,255,255,0.95); backdrop-filter: blur(20px); } 
    </style>
</head>
<body class="d-flex align-items-center">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card login-card shadow-lg p-5">
                    <h2 class="text-success text-center mb-4">🌱 Register</h2>
                    <?php if (isset($error)): ?><div class="alert alert-danger"><?php echo $error; ?></div><?php endif; ?>
                    <?php if (isset($_GET['success'])): ?><div class="alert alert-success">Registered! Please login.</div><?php endif; ?>
                    
                    <form method="POST">
                        <div class="row g-3">
                            <div class="col-md-12">
                                <label class="form-label fw-bold text-success">Username</label>
                                <input type="text" name="username" class="form-control form-control-lg" placeholder="Enter username" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-success">Email</label>
                                <input type="email" name="email" class="form-control form-control-lg" placeholder="your@gmail.com" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label fw-bold text-success">Contact Number</label>
                                <input type="tel" name="contact" class="form-control form-control-lg" placeholder="Enter Mobile No." required maxlength="10">
                            </div>
                            <div class="col-md-12">
                                <label class="form-label fw-bold text-success">Password</label>
                                <input type="password" name="password" class="form-control form-control-lg" placeholder="Minimum 6 characters" required minlength="6">
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-success w-100 btn-lg mt-4">
                            <i class="fas fa-user-plus me-2"></i>Create Account
                        </button>
                    </form>
                    
                    <p class="text-center mt-4 mb-0">
                        Already registered? <a href="login.php" class="text-success fw-bold">Login here</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>